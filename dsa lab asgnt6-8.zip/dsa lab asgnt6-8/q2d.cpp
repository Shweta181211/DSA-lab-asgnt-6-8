#include <iostream>
using namespace std;

class Node {
public:
    int data;
    Node* left;
    Node* right;

    Node(int val) {
        data = val;
        left = right = NULL;
    }
};

Node* insert(Node* root, int key) {
    if (root == NULL) return new Node(key);
    if (key < root->data) root->left = insert(root->left, key);
    else if (key > root->data) root->right = insert(root->right, key);
    return root;
}

Node* findMin(Node* root) {
    while (root && root->left) root = root->left;
    return root;
}

Node* findMax(Node* root) {
    while (root && root->right) root = root->right;
    return root;
}

// Find inorder successor
Node* inorderSuccessor(Node* root, int key) {
    Node* succ = NULL;
    while (root) {
        if (key < root->data) {
            succ = root;
            root = root->left;
        } else if (key > root->data) {
            root = root->right;
        } else {
            if (root->right)
                succ = findMin(root->right);
            break;
        }
    }
    return succ;
}

Node* inorderPredecessor(Node* root, int key) {
    Node* pred = NULL;
    while (root) {
        if (key > root->data) {
            pred = root;
            root = root->right;
        } else if (key < root->data) {
            root = root->left;
        } else {
            if (root->left)
                pred = findMax(root->left);
            break;
        }
    }
    return pred;
}

int main() {
    Node* root = NULL;
    int values[] = {50, 30, 20, 40, 70, 60, 80};
    for (int v : values) root = insert(root, v);

    int key = 50;

    Node* succ = inorderSuccessor(root, key);
    Node* pred = inorderPredecessor(root, key);

    if (succ) cout << "Inorder Successor of " << key << " is " << succ->data << endl;
    else cout << "No Inorder Successor for " << key << endl;

    if (pred) cout << "Inorder Predecessor of " << key << " is " << pred->data << endl;
    else cout << "No Inorder Predecessor for " << key << endl;

    return 0;
}
