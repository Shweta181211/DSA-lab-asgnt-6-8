#include<iostream>
#include<vector>
using namespace std;

class Node{
    public:
    int data;
    Node* left;
    Node* right;

    Node(int val){
        data=val;
        left=right=NULL;
    }
};
int idx=-1;
Node* buildTree(vector <int> inOrder){
    idx++;

    if(inOrder[idx]==-1){
        return NULL;
    }
    Node* root=new Node(inOrder[idx]);
    root->left=buildTree(inOrder);
    root->right=buildTree(inOrder);
    return root;
}

void printIN(Node* root){
    if(root==NULL){
        return;
    }

    cout<<root->data;
    printIN(root->left);
    printIN(root->right);
}

int main(){
    vector<int> inOrder={1,2,5,-1,8,3,-1,-1};
    Node* root=buildTree(inOrder);
    printIN(root);
    cout<<endl;
    return 0;
}