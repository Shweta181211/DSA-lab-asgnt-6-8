#include<iostream>
using namespace std;

class Node{
    public:
    int data;
    Node* left;
    Node* right;

    Node(int val){
        data=val;
        left=right=NULL;
    }
};

Node* insert(Node* root,int key){
    if(!root) return new Node(key);
    if(key<root->data) root->left=insert(root->left,key);
    else if(key>root->data) root->right=insert(root->right,key);
    return root;
}

Node* rs(Node* root,int key){
    if(!root) return NULL;
    if(root->data==key) return root;
    if(key<root->data) return rs(root->left,key);
    return rs(root->right,key);
}

Node* is(Node* root,int key){
    Node* curr=root;
    while(curr){
        if(curr->data==key) return curr;
        if(key<curr->data) curr=curr->left;
        else curr=curr->right;
    }
    return NULL;
}

int main(){
Node* root=NULL;
int values[]={50,30,20,40,70,60,80};
for(int v: values) root=insert(root,v);

int key;
cout<<"enter key to search: ";
cin>>key;

Node* r = rs(root, key);
cout << "Recursive search: " << (r ? "Found" : "Not Found") << '\n';

Node* it = is(root, key);
cout << "Iterative search: " << (it ? "Found" : "Not Found") << '\n';

}