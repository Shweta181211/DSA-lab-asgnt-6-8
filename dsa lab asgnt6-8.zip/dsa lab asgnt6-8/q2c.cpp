#include<iostream>
using namespace std;

class Node{
    public:
    int data;
    Node* next;
    Node* left;
    Node* right;

    Node(int val){
        data=val;
        left=right=NULL;
    }
};

Node* insert(Node* root,int key){
    if(!root) return new Node(key);
    if(key<root->data) root->left=insert(root->left,key);
    else if(key>root->data) root->right=insert(root->right,key);
    return root;
}

Node* findMax(Node* root) {
    if (root == nullptr) return nullptr; // empty tree
    Node* curr = root;
    while (curr->right != nullptr) {
        curr = curr->right;
    }
    return curr;
}

int main(){
Node* root=NULL;
int values[]={50,30,20,40,70,60,80};
for(int v: values) root=insert(root,v);

Node* mn = findMax(root);
    if (mn) cout << "Maximum element: " << mn->data << endl;
    else cout << "Tree is empty\n";

    return 0;
}