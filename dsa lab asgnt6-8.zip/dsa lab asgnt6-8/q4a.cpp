#include <iostream>
#include <vector>
using namespace std;

class Node{
public:
    int data;
    Node* left;
    Node* right;
    Node(int val): data(val), left(nullptr), right(nullptr) {}
};

int idx = -1;

Node* buildTree(vector<int>& inOrder){
    idx++;
    if (idx >= (int)inOrder.size() || inOrder[idx] == -1) return nullptr;
    Node* root = new Node(inOrder[idx]);
    root->left  = buildTree(inOrder);
    root->right = buildTree(inOrder);
    return root; // ← yahi pehle missing tha
}

void inOrderPrint(Node* root){
    if (root==NULL) return;
    inOrder(root->left);
    cout<<root->data<<" ";
    inOrder(root->right);
}

int main(){
    vector<int> inOrder = {1,2,-1,-1,3,4,-1,-1,5,-1,-1};
    Node* root = buildTree(inOrder);
    inOrderPrint(root);
    cout << endl;
    return 0;
}