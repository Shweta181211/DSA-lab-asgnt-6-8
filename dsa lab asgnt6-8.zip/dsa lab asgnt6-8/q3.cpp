#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* left;
    Node* right;
    Node(int val){
        data=val;
        left=right=NULL;
    }
};

Node* insert(Node* root, int key) {
    if (root == nullptr) return new Node(key);
    if (key < root->data) root->left = insert(root->left, key);
    else if (key > root->data) root->right = insert(root->right, key);
    return root;
}

Node* findMin(Node* root) {
    while (root && root->left) root = root->left;
    return root;
}

Node* deleteNode(Node* root, int key) {
    if (root == nullptr) return nullptr;
    if (key < root->data) {
        root->left = deleteNode(root->left, key);
    } else if (key > root->data) {
        root->right = deleteNode(root->right, key);
    } else {
    
        if (root->left == nullptr && root->right == nullptr) {
            delete root;
            return nullptr;
        } else if (root->left == nullptr) {
            Node* tmp = root->right;
            delete root;
            return tmp;
        } else if (root->right == nullptr) {
            Node* tmp = root->left;
            delete root;
            return tmp;
        } else {
            
            Node* succ = findMin(root->right);
            root->data = succ->data;
            root->right = deleteNode(root->right, succ->data);
        }
    }
    return root;
}

int maxDepth(Node* root) {
    if (root == nullptr) return 0;
    int lh = maxDepth(root->left);
    int rh = maxDepth(root->right);
    return 1 + (lh > rh ? lh : rh);
}

int minDepth(Node* root) {
    if (root == nullptr) return 0;
    if (root->left == nullptr) return 1 + minDepth(root->right);
    if (root->right == nullptr) return 1 + minDepth(root->left);
    int lh = minDepth(root->left);
    int rh = minDepth(root->right);
    return 1 + (lh < rh ? lh : rh);
}

void inorder(Node* root) {
    if (!root) return;
    inorder(root->left);
    cout << root->data << " ";
    inorder(root->right);
}

int main() {
    Node* root = nullptr;\
    int values[] = {50, 30, 20, 40, 70, 60, 80};
    for (int v : values) root = insert(root, v);

    cout << "Inorder (initial): ";
    inorder(root);
    cout << "\n";

    cout << "Max depth: " << maxDepth(root) << "\n";
    cout << "Min depth: " << minDepth(root) << "\n";

    root = deleteNode(root, 20);
    cout << "After deleting 20: ";
    inorder(root);
    cout << "\n";

    root = deleteNode(root, 30);
    cout << "After deleting 30: ";
    inorder(root);
    cout << "\n";

    root = deleteNode(root, 50);
    cout << "After deleting 50: ";
    inorder(root);
    cout << "\n";

    cout << "Max depth now: " << maxDepth(root) << "\n";
    cout << "Min depth now: " << minDepth(root) << "\n";

    return 0;
}
